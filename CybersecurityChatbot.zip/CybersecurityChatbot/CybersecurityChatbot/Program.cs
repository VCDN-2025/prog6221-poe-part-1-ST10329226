﻿using System;
using System.Media;
using System.Threading;
using Figgle;

namespace CybersecurityChatbot
{
    public class CybersecurityChatbot
    {
        // Automatic property for the user's name (Learning Units 1 & 2)
        public string UserName { get; private set; }

        public static void Main(string[] args)
        {
            // 1. Voice Greeting (10 Marks)
            // Create an instance of AudioPlayer and call PlayGreeting
            AudioPlayer audioPlayer = new AudioPlayer();
            audioPlayer.PlayGreeting();

            // 2. Image Display (10 Marks)
            DisplayAsciiArt();

            // 3. Text-Based Greeting and User Interaction (10 Marks)
            GetUserAndDisplayGreeting();

            // 4. Basic Response System (15 Marks)
            StartConversation();
        }



        // 2. Image Display - Displays ASCII art logo
        static void DisplayAsciiArt()
        {
            // Choose a Figgle font (you can experiment with others)
            var font = FiggleFonts.Standard; // A common and readable font

            // Generate the ASCII art banner for "Chatbot"
            string banner = font.Render("Chatbot");

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(banner);
            Console.ResetColor();
            Console.WriteLine("[Cybersecurity Awareness Bot Banner Displayed using Figgle]"); // Feedback
        }
        // 3. Text-Based Greeting and User Interaction - Gets user name and welcomes them
        static void GetUserAndDisplayGreeting()
        {
            Console.WriteLine("\nPlease enter your name:");
            string userName = Console.ReadLine();
            // Applying string manipulation to personalize the greeting (Learning Units 1 & 2)
            Console.WriteLine($"\nWelcome, {userName}! I'm your Cybersecurity Awareness Bot.");
            Console.WriteLine("I'm here to help you learn about staying safe online.");

            //Store the username.  Important for later personalized responses.
            CybersecurityChatbot bot = new CybersecurityChatbot();
            bot.UserName = userName;
        }

        // 4. Basic Response System - Handles user input and provides responses
        static void StartConversation()
        {
            Console.WriteLine("\nHere are some topics you can ask me about:");
            Console.WriteLine("- Password Safety");
            Console.WriteLine("- Phishing");
            Console.WriteLine("- Safe Browsing");
            Console.WriteLine("- Malware"); //Added Malware
            Console.WriteLine("- How are you?");
            Console.WriteLine("- What's your purpose?");
            Console.WriteLine("- What can I ask you about?");
            Console.WriteLine("\nYou can also type 'exit' to quit.");

            while (true)
            {
                Console.WriteLine("\nWhat cybersecurity topic are you interested in? (Type 'exit' to quit)");
                string userInput = Console.ReadLine().ToLower();

                if (userInput == "exit")
                {
                    Console.WriteLine("Thank you for using the Cybersecurity Awareness Bot. Stay safe online!");
                    break;
                }

                // Get a response based on user input
                string response = GetResponse(userInput);
                Console.WriteLine(response);
            }
        }

        // 4. Basic Response System - Generates responses to user queries
        static string GetResponse(string userInput)
        {
            // 5. Input Validation - Handling empty or null input (5 Marks)
            if (string.IsNullOrWhiteSpace(userInput))
            {
                return "I didn't quite understand that. Could you rephrase?"; // Informative message
            }

            // String manipulation for more robust keyword detection
            userInput = userInput.Trim().ToLower();

            // Basic predefined responses covering password safety, phishing, and safe browsing
            if (userInput.Contains("how are you"))
            {
                return "I'm doing well, thank you! Ready to help you with cybersecurity."; // Natural conversation
            }
            else if (userInput.Contains("what's your purpose"))
            {
                return "My purpose is to educate you about cybersecurity and help you stay safe online."; // Clear and concise
            }
            else if (userInput.Contains("what can i ask you about"))
            {
                return "You can ask me about password safety, phishing, safe browsing, and malware."; // Guides the user
            }
            else if (userInput.Contains("password") && userInput.Contains("strength"))
            {
                return "For good password safety, use strong, unique passwords for different accounts. A strong password includes a mix of uppercase and lowercase letters, numbers, and symbols. Avoid using personal information that is easy to guess."; // Depth and clarity
            }
            else if (userInput.Contains("phishing"))
            {
                return "Phishing is a type of online fraud where attackers try to trick you into revealing sensitive information like usernames, passwords, and credit card details. They often use deceptive emails, messages, or fake websites that look legitimate. Be wary of unsolicited requests for personal information."; // Depth and clarity
            }
            else if (userInput.Contains("safe browsing") || userInput.Contains("suspicious links"))
            {
                return "To browse safely, be cautious of suspicious links in emails or on websites. Always check the URL to ensure it's legitimate and look for the padlock icon (HTTPS) indicating a secure connection. Avoid downloading files or clicking on links from untrusted sources."; // Depth and clarity
            }

            else if (userInput.Contains("malware") || userInput.Contains("virus"))
            {
                return "Malware is software designed to harm or disrupt your computer system. Protect yourself by installing reputable antivirus software, keeping it updated, and being cautious about downloading files or clicking on links.";
            }

            else
            {
                // 5. Input Validation - Handling unsupported queries (5 Marks)
                return "I'm still learning about that topic. Could you ask me something about password safety, phishing, or safe browsing?"; // Helpful guidance
            }
        }
    }
}



