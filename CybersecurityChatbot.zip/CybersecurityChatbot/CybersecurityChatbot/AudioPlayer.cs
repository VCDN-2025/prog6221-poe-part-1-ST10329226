﻿using System;
using System.Media;

namespace CybersecurityChatbot // Make sure this namespace matches your project's namespace
{
    public class AudioPlayer
    {
        public void PlayGreeting()
        {
            try
            {
                SoundPlayer player = new SoundPlayer();
                player.SoundLocation = "greeting.wav"; // This is where we'll fix the path
                player.PlaySync();
                Console.WriteLine("Playing the greeting...");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
    }
}
